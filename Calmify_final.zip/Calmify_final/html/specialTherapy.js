document.addEventListener("DOMContentLoaded", function () {
    // Get necessary elements
    const submitButton = document.getElementById("submitButton");
    const inputField = document.querySelector(".input_box");
    const chatContainer = document.getElementById("chat-container");

    // Ensure all required elements exist before adding event listeners
    if (!submitButton || !inputField || !chatContainer) {
        console.error("Error: One or more required elements are missing!");
        return;
    }

    // Add event listener for submit button
    submitButton.addEventListener("click", processUserMessage);

    // Allow Enter key to trigger submit
    inputField.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            processUserMessage();
        }
    });

    function processUserMessage() {
        const userInput = inputField.value.trim();

        if (userInput === "") {
            return; // Ignore empty messages
        }

        // Display user message
        addMessageToChatBox("user", userInput);
        inputField.value = ""; // Clear input field

        // Simulating chatbot response
        let botResponse = getBotResponse(userInput);
        setTimeout(() => {
            addMessageToChatBox("bot", botResponse);
        }, 1000);
    }

    function addMessageToChatBox(sender, message) {
        const messageDiv = document.createElement("div");
        messageDiv.classList.add(sender === "user" ? "user-message" : "bot-message");
        messageDiv.textContent = message;
        chatContainer.appendChild(messageDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight; // Auto-scroll to latest message
    }

    function getBotResponse(input) {
        input = input.toLowerCase();
        if (input.includes("hello") || input.includes("hi")) {
            return "Hello! How can I assist you today?";
        } else if (input.includes("help")) {
            return "Sure! I’m here to help. What do you need assistance with?";
        } else if (input.includes("bye")) {
            return "Goodbye! Have a great day.";
        } else {
            return "I'm sorry, I don't understand that. Can you rephrase?";
        }
    }
});

// Handle menu toggling for mobile navigation
document.addEventListener("DOMContentLoaded", function () {
    const ham = document.getElementById("ham");
    const menu = document.getElementById("menu");
    const closeButtons = document.querySelectorAll(".close");

    if (ham && menu) {
        ham.addEventListener("click", function () {
            if (menu.classList.contains("open")) {
                closeMenu();
            } else {
                menu.classList.add("open");
                ham.innerHTML = `
                <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 1024 1024" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
                    <path d="M563.8 512l262.5-312.9c4.4-5.2.7-13.1-6.1-13.1h-79.8c-4.7 0-9.2 2.1-12.3 5.7L511.6 449.8 295.1 191.7c-3-3.6-7.5-5.7-12.3-5.7H203c-6.8 0-10.5 7.9-6.1 13.1L459.4 512 196.9 824.9A7.95 7.95 0 0 0 203 838h79.8c4.7 0 9.2-2.1 12.3-5.7l216.5-258.1 216.5 258.1c3 3.6 7.5 5.7 12.3 5.7h79.8c6.8 0 10.5-7.9 6.1-13.1L563.8 512z"></path>
                </svg>`;
            }
        });

        function closeMenu() {
            menu.classList.remove("open");
            console.log("Menu closed");
        }

        closeButtons.forEach(btn => btn.addEventListener("click", closeMenu));
    }
});

// Chatbot API Integration (Optional: Replace API Key)
const promptInput = document.querySelector("#prompt");
const container = document.querySelector(".container");
const chatContainer = document.querySelector(".chat-container");
const apiUrl = "https://your-api-url.com"; // Replace with actual API endpoint

async function getApiResponse(userMessage) {
    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userMessage })
        });

        const data = await response.json();
        return data.reply || "I'm sorry, I couldn't process that.";
    } catch (error) {
        console.error("API Error:", error);
        return "There was an error processing your request.";
    }
}

function showLoading() {
    const aiChatBox = createChatBox(`
        <div class="img"><img src="ai.png" alt="" width="50"></div>
        <p class="text"></p>
        <img class="loading" src="loading.gif" alt="loading" height="50">`, "ai-chat-box");
    
    chatContainer.appendChild(aiChatBox);
    getApiResponse(promptInput.value).then(response => {
        aiChatBox.querySelector(".text").innerText = response;
        aiChatBox.querySelector(".loading").style.display = "none";
    });
}

document.getElementById("btn").addEventListener("click", function () {
    const userMessage = promptInput.value.trim();
    if (!userMessage) return;

    const userChatBox = createChatBox(`
        <div class="img"><img src="user.png" alt="" width="50"></div>
        <p class="text">${userMessage}</p>`, "user-chat-box");

    chatContainer.appendChild(userChatBox);
    promptInput.value = "";
    setTimeout(showLoading, 500);
});

// Utility function to create chat box elements
function createChatBox(html, className) {
    const div = document.createElement("div");
    div.classList.add(className);
    div.innerHTML = html;
    return div;
}

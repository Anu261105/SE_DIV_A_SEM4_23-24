const chatbotToggler = document.querySelector(".chatbot-toggler");
const closeBtn = document.querySelector(".close-btn");
const chatbox = document.querySelector(".chatbox");
const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");

let userMessage = null;
const inputInitHeight = chatInput.scrollHeight;

const createChatLi = (message, className) => {
    const chatLi = document.createElement("li");
    chatLi.classList.add("chat", className);
    let chatContent = className === "outgoing" 
        ? `<p></p>` 
        : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
    
    chatLi.innerHTML = chatContent;
    chatLi.querySelector("p").textContent = message;
    return chatLi;
};

const generateResponse = async (chatElement, userMessage) => {
    const OPENAI_API_KEY = "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"; // Replace with your actual API key
    const apiUrl = "https://api.openai.com/v1/chat/completions";

    chatElement.querySelector("p").textContent = "Thinking...";

    try {
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `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}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are a helpful assistant, you provide short and brief responses to the best of your ability." },
                    { role: "user", content: userMessage }
                ]
            })
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.statusText}`);
        }

        const data = await response.json();
        const aiResponse = data.choices[0].message.content.trim();

        chatElement.querySelector("p").textContent = aiResponse;
    } catch (error) {
        console.error("Error fetching response:", error);
        chatElement.querySelector("p").textContent = "Error fetching response. Please try again.";
    }

    chatbox.scrollTo(0, chatbox.scrollHeight);
};

const handleChat = () => {
    userMessage = chatInput.value.trim();
    if (!userMessage) return;

    chatInput.value = "";
    chatInput.style.height = `${inputInitHeight}px`;

    chatbox.appendChild(createChatLi(userMessage, "outgoing"));
    chatbox.scrollTo(0, chatbox.scrollHeight);

    setTimeout(() => {
        const incomingChatLi = createChatLi("Thinking...", "incoming");
        chatbox.appendChild(incomingChatLi);
        chatbox.scrollTo(0, chatbox.scrollHeight);
        generateResponse(incomingChatLi, userMessage);
    }, 600);
};

chatInput.addEventListener("input", () => {
    chatInput.style.height = `${inputInitHeight}px`;
    chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
        e.preventDefault();
        handleChat();
    }
});

sendChatBtn.addEventListener("click", handleChat);
closeBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));
